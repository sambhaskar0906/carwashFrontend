import { configureStore } from "@reduxjs/toolkit";
import AuthSlice, { setUserData, getAllCarType } from "./slices/AuthSlice";
import CarSlice from "./slices/CarSlice"

const store = configureStore({
    reducer: {
        AUTH: AuthSlice,
        CAR: CarSlice,

    }
})


store.dispatch(setUserData())

export default store;